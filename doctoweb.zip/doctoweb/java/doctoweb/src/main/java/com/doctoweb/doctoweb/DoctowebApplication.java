package com.doctoweb.doctoweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DoctowebApplication {

	public static void main(String[] args) {
		SpringApplication.run(DoctowebApplication.class, args);
	}
}
